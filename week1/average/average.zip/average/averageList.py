# Create a program that prints the average of the values in the list: 
# a = [1, 2, 5, 10, 255, 3]

a = [1, 2, 5, 10, 255, 3]
average = sum(a)/len(a) #276 / 6	
print average #46