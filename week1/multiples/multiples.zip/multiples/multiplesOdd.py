#Create program that prints all odd numbers from  1 to 1000 using for loop and not using an array
for count in range(0,1000):
	if(count%2 == 1):
		print count