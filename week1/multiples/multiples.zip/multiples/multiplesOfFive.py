#Create another program that prints all the multiples of 5 from 5 to 1,000,000.
for count in range(5, 1000000):
	multiple = count * 5
	print multiple